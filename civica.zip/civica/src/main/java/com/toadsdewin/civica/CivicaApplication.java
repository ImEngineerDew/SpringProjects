package com.toadsdewin.civica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CivicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CivicaApplication.class, args);
	}

}
