package com.toadsdewin.civica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CivicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
