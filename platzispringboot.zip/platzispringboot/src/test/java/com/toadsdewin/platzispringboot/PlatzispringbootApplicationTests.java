package com.toadsdewin.platzispringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlatzispringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
